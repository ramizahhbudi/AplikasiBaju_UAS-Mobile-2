package com.kelompok3.aplikasibaju.Model

data class OrderModel(
    val id: String,
    val items: List<CartItemModel>,
    val totalAmount: Int,
    val orderTime: Long = System.currentTimeMillis()
)