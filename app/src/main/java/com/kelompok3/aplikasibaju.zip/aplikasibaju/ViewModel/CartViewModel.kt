package com.kelompok3.aplikasibaju.ViewModel

import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.kelompok3.aplikasibaju.Model.CartItemModel
import com.kelompok3.aplikasibaju.Model.ItemsModel
import com.kelompok3.aplikasibaju.Model.OrderModel
import java.util.*

class CartViewModel : ViewModel() {

    private val firebaseDatabase = FirebaseDatabase.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val _cartItems = MutableLiveData<List<CartItemModel>>()
    val cartItems: LiveData<List<CartItemModel>> get() = _cartItems

    // Load cart items from Firebase with suspend
    suspend fun loadCartItems() {
        val userId = auth.currentUser?.uid
        if (userId == null) {
            Log.e("CartViewModel", "User not authenticated")
            return
        }

        val userRef = firebaseDatabase.getReference("users").child(userId).child("cart")
        userRef.get().addOnSuccessListener { snapshot ->
            val cartItemsList = mutableListOf<CartItemModel>()
            snapshot.children.forEach { childSnapshot ->
                val cartItem = childSnapshot.getValue(CartItemModel::class.java)
                cartItem?.let {
                    // Fetch the corresponding item details from "Items" node
                    val itemRef = firebaseDatabase.getReference("Items").child(it.item.id)
                    itemRef.get().addOnSuccessListener { itemSnapshot ->
                        val item = itemSnapshot.getValue(ItemsModel::class.java)
                        item?.let {
                            val updatedCartItem = CartItemModel(
                                item = it,
                                selectedModel = cartItem.selectedModel,
                                quantity = cartItem.quantity,
                                firebaseId = cartItem.firebaseId
                            )
                            cartItemsList.add(updatedCartItem)
                        }
                    }
                }
            }
            _cartItems.value = cartItemsList
        }.addOnFailureListener {
            Log.e("CartViewModel", "Error loading cart data", it)
        }
    }

    // Update item quantity in the cart
    fun updateItemQuantity(cartItem: CartItemModel, newQuantity: Int) {
        val userId = auth.currentUser?.uid ?: return

        if (newQuantity <= 0) {
            removeItem(cartItem) // Remove item if quantity is 0 or negative
            return
        }

        val cartRef = firebaseDatabase.getReference("users/$userId/cart")
        cartRef.child(cartItem.firebaseId).child("quantity").setValue(newQuantity)
            .addOnSuccessListener {
                Log.d("CartViewModel", "Item quantity updated successfully")
                // Update local cartItems list after the quantity change
                cartItem.quantity = newQuantity
                _cartItems.value = _cartItems.value // Trigger LiveData observer to update UI
            }
            .addOnFailureListener { exception ->
                Log.e("CartViewModel", "Failed to update item quantity", exception)
            }
    }

    // Remove item from the cart
    fun removeItem(cartItem: CartItemModel) {
        val userId = auth.currentUser?.uid ?: return

        val cartRef = firebaseDatabase.getReference("users/$userId/cart")
        cartRef.child(cartItem.firebaseId).removeValue()
            .addOnSuccessListener {
                Log.d("CartViewModel", "Item removed successfully")
                // Remove the item from the local list
                _cartItems.value = _cartItems.value?.filter { it.firebaseId != cartItem.firebaseId }
            }
            .addOnFailureListener { exception ->
                Log.e("CartViewModel", "Failed to remove item", exception)
            }
    }

    // Calculate the total amount of all items in the cart
    fun getTotalAmount(): Int {
        return _cartItems.value?.sumOf { it.item.price * it.quantity } ?: 0
    }

    // Checkout function
    fun checkout(): OrderModel {
        val order = OrderModel(
            id = UUID.randomUUID().toString(),
            items = _cartItems.value ?: emptyList(),
            totalAmount = getTotalAmount()
        )

        val userId = auth.currentUser?.uid ?: return order
        val ordersRef = firebaseDatabase.getReference("users/$userId/orders")

        ordersRef.child(order.id).setValue(order)
            .addOnSuccessListener {
                Log.d("CartViewModel", "Order created successfully")
                clearCart()
            }
            .addOnFailureListener { exception ->
                Log.e("CartViewModel", "Failed to create order", exception)
            }

        return order
    }

    // Clear the cart after checkout
    private fun clearCart() {
        val userId = auth.currentUser?.uid ?: return
        val cartRef = firebaseDatabase.getReference("users/$userId/cart")

        cartRef.removeValue()
            .addOnSuccessListener {
                Log.d("CartViewModel", "Cart cleared successfully")
                _cartItems.value = emptyList() // Clear local cartItems
            }
            .addOnFailureListener { exception ->
                Log.e("CartViewModel", "Failed to clear cart", exception)
            }
    }

    fun addToCart(item: ItemsModel, selectedModel: String) {
        val userId = auth.currentUser?.uid
        if (userId == null) {
            Log.e("CartViewModel", "Cannot add to cart: User not authenticated")
            return
        }

        val cartRef = firebaseDatabase.getReference("users/$userId/cart")

        // Generate a unique key for the cart item in Firebase
        val newCartItemRef = cartRef.push()
        val firebaseId = newCartItemRef.key

        if (firebaseId == null) {
            Log.e("CartViewModel", "Failed to generate Firebase ID")
            return
        }

        // Create CartItemModel
        val cartItem = CartItemModel(
            item = item,
            selectedModel = selectedModel,
            quantity = 1, // Default quantity is 1
            firebaseId = firebaseId
        )

        // Save cart item to Firebase
        newCartItemRef.setValue(cartItem)
            .addOnSuccessListener {
                Log.d("CartViewModel", "Item added to cart successfully: ${item.title}")
                // You can also update the local _cartItems LiveData here if needed
            }
            .addOnFailureListener { exception ->
                Log.e("CartViewModel", "Failed to add item to cart", exception)
            }
    }


}
