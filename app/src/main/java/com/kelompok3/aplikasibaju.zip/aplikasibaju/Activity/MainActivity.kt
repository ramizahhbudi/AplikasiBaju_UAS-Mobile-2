package com.kelompok3.aplikasibaju.Activity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.core.view.WindowCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.FirebaseApp
import com.kelompok3.aplikasibaju.AddAddressScreen
import com.kelompok3.aplikasibaju.CartScreen
import com.kelompok3.aplikasibaju.Helper.SessionManager
import com.kelompok3.aplikasibaju.HomeScreen
import com.kelompok3.aplikasibaju.LoginSignup.LoginScreen
import com.kelompok3.aplikasibaju.LoginSignup.SignupScreen
/*import com.kelompok3.aplikasibaju.OrderScreen*/
import com.kelompok3.aplikasibaju.ProfileScreen
import com.kelompok3.aplikasibaju.ui.theme.AplikasiBajuTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        FirebaseApp.initializeApp(this)

        WindowCompat.setDecorFitsSystemWindows(window, false)

        val sessionManager = SessionManager(this)

        setContent {
            AplikasiBajuTheme {
                val isLoggedIn = remember { mutableStateOf(sessionManager.getUserEmail() != null) }

                AuthApp(isLoggedIn.value, onLoginSuccess = { email ->
                    sessionManager.saveUserEmail(email)
                    isLoggedIn.value = true
                }, onLogout = {
                    sessionManager.clearSession()
                    isLoggedIn.value = false
                })
            }
        }
    }
}

@Composable
fun AuthApp(
    isLoggedIn: Boolean,
    onLoginSuccess: (String) -> Unit,
    onLogout: () -> Unit
) {
    val navController = rememberNavController()

    LaunchedEffect(isLoggedIn) {
        if (isLoggedIn) {
            navController.navigate("home") {
                popUpTo("login") { inclusive = true }
            }
        } else {
            navController.navigate("login") {
                popUpTo("home") { inclusive = true }
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = if (isLoggedIn) "home" else "login"
    ) {
        composable("login") {
            LoginScreen(navController, onLoginSuccess)
        }
        composable("signup") { SignupScreen(navController) }
        composable("home") { HomeScreen(navController, onLogout) }
        composable("cart") {
            CartScreen(
                onCheckout = {
                    navController.navigate("order")
                },
                navController = navController // <- ini yang kurang
            )
        }
       /* composable("order") {
            OrderScreen(navController = navController)
        }
*/
      /* composable("cart") {
           CartScreen(navController)
       }*/
//        composable("order") { OrderScreen(navController) }
        composable("profile") {
            ProfileScreen(navController)
        }
        composable("add_address") {
            AddAddressScreen(
                onBack = { navController.popBackStack() }
            )
        }
    }
}