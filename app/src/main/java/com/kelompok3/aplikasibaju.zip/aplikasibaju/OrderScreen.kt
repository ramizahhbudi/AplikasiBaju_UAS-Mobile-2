package com.kelompok3.aplikasibaju

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Divider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kelompok3.aplikasibaju.ViewModel.CartViewModel
import androidx.compose.foundation.layout.*
import androidx.compose.ui.unit.dp

/*
@Composable
fun OrderScreen(
    navController: NavHostController,
    cartViewModel: CartViewModel = viewModel()
) {
    val orders = cartViewModel.getOrders()  // Get orders using the updated CartViewModel

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 56.dp)
        ) {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(orders) { order ->  // Display each order
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Order ID: ${order.id}")
                        order.items.forEach {
                            Text("${it.item.title} (${it.selectedModel}) x${it.quantity}")
                        }
                        Text("Total: Rp ${order.totalAmount}")
                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                    }
                }
            }
        }

        BottomMenu(
            selected = "order",
            onItemClick = { menu ->
                when (menu) {
                    "home" -> navController.navigate("home")
                    "cart" -> navController.navigate("cart")
                    "order" -> {} // stay
                    "profile" -> navController.navigate("profile")
                }
            },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}*/
