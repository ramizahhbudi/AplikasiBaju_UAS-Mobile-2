package com.kelompok3.aplikasibaju.ViewModel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import kotlinx.coroutines.launch
import android.util.Log
import com.kelompok3.aplikasibaju.Model.*
import com.kelompok3.aplikasibaju.Repository.RetrofitClient

class WilayahViewModel : ViewModel() {

    private val _provinces = MutableLiveData<List<Province>>()
    val provinces: LiveData<List<Province>> get() = _provinces

    private val _regencies = MutableLiveData<List<Regency>>()
    val regencies: LiveData<List<Regency>> get() = _regencies

    private val _districts = MutableLiveData<List<District>>()
    val districts: LiveData<List<District>> get() = _districts

    private val _villages = MutableLiveData<List<Village>>()
    val villages: LiveData<List<Village>> get() = _villages

    fun fetchProvinces() {
        viewModelScope.launch {
            try {
                _provinces.value = RetrofitClient.instance.getProvinces()
            } catch (e: Exception) {
                Log.e("WilayahVM", "Gagal ambil provinsi", e)
            }
        }
    }

    fun fetchRegencies(provinceId: String) {
        viewModelScope.launch {
            try {
                _regencies.value = RetrofitClient.instance.getRegencies(provinceId)
            } catch (e: Exception) {
                Log.e("WilayahVM", "Gagal ambil kabupaten", e)
            }
        }
    }

    fun fetchDistricts(regencyId: String) {
        viewModelScope.launch {
            try {
                _districts.value = RetrofitClient.instance.getDistricts(regencyId)
            } catch (e: Exception) {
                Log.e("WilayahVM", "Gagal ambil kecamatan", e)
            }
        }
    }

    fun fetchVillages(districtId: String) {
        viewModelScope.launch {
            try {
                _villages.value = RetrofitClient.instance.getVillages(districtId)
            } catch (e: Exception) {
                Log.e("WilayahVM", "Gagal ambil kelurahan", e)
            }
        }
    }
}