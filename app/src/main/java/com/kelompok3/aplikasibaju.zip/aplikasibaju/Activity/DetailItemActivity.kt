package com.kelompok3.aplikasibaju.Activity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.rememberNavController
import com.kelompok3.aplikasibaju.Model.ItemsModel
import com.kelompok3.aplikasibaju.ViewModel.CartViewModel
import com.kelompok3.aplikasibaju.ui.theme.AplikasiBajuTheme
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import coil.compose.rememberAsyncImagePainter

class DetailItemActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val item = try {
            intent.getSerializableExtra("item") as? ItemsModel
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }

        setContent {
            AplikasiBajuTheme {
                val navController = rememberNavController()
                val cartViewModel: CartViewModel = viewModel() // Get shared ViewModel

                Surface(modifier = Modifier.fillMaxSize()) {
                    if (item != null) {
                        DetailItemScreen(
                            item = item,
                            onBack = { finish() },
                            navController = navController,
                            cartViewModel = cartViewModel // Pass ViewModel to DetailItemScreen
                        )
                    } else {
                        Text("Data produk tidak tersedia", modifier = Modifier.padding(16.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailItemScreen(
    item: ItemsModel,
    onBack: () -> Unit,
    navController: NavHostController,
    cartViewModel: CartViewModel = viewModel() // Receive shared ViewModel
) {
    var selectedModel by remember { mutableStateOf("") }
    var showSnackbar by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    var quantity by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detail Produk") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            BottomAppBar {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Total\nRp ${item.price * quantity}",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Button(
                        onClick = {
                            if (selectedModel.isNotEmpty() && quantity > 0) {
                                repeat(quantity) {
                                    cartViewModel.addToCart(item, selectedModel) // Menambahkan item ke cart
                                }
                                showSnackbar = true
                            }
                        },
                        enabled = quantity > 0 && selectedModel.isNotEmpty(),
                        modifier = Modifier
                            .height(48.dp)
                    ) {
                        Text("Tambah ke Keranjang")
                    }
                }
            }
        }
    ) { paddingValues ->

        LaunchedEffect(showSnackbar) {
            if (showSnackbar) {
                snackbarHostState.showSnackbar("Produk ditambahkan ke keranjang!")
                showSnackbar = false
            }
        }

        Column(
            modifier = Modifier
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Galeri Gambar
            LazyRow(modifier = Modifier.height(200.dp)) {
                items(item.picUrl) { url ->
                    val painter = rememberAsyncImagePainter(model = url)
                    Image(
                        painter = painter,
                        contentDescription = item.title,
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .size(200.dp),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(item.title, style = MaterialTheme.typography.headlineSmall)
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Rp ${item.price}", style = MaterialTheme.typography.headlineSmall)
                Text("⭐ ${item.rating}", style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Jumlah", style = MaterialTheme.typography.titleMedium)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start
            ) {
                IconButton(onClick = { if (quantity > 0) quantity-- }) {
                    Text("-")
                }
                Text(quantity.toString(), modifier = Modifier.width(24.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                IconButton(onClick = { quantity++ }) {
                    Text("+")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Deskripsi Produk", style = MaterialTheme.typography.titleMedium)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Text(
                    item.description,
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (item.model.isNotEmpty()) {
                Text("Varian Tersedia", style = MaterialTheme.typography.titleMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    item.model.forEach { modelName ->
                        val isSelected = modelName == selectedModel
                        Button(
                            onClick = { selectedModel = modelName },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer
                            )
                        ) {
                            Text(modelName)
                        }
                    }
                }
            }
        }
    }
}