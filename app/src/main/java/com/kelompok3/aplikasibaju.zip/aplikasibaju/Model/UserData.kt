package com.kelompok3.aplikasibaju.Model

data class UserData (
    val username: String="",
    val email: String="",
    val no_hp: String = "",
    val fullName: String="",
    val address: String = ""
)